package entities;

public class CardRanking {
	
	private int intCardRanking = -1;
	
	private String stringCardRanking = null;

	public int getIntCardRanking() {
		return intCardRanking;
	}

	public void setIntCardRanking(int intCardRanking) {
		this.intCardRanking = intCardRanking;
	}

	public String getStringCardRanking() {
		return stringCardRanking;
	}

	public void setStringCardRanking(String stringCardRanking) {
		this.stringCardRanking = stringCardRanking;
	}
	
	

}
